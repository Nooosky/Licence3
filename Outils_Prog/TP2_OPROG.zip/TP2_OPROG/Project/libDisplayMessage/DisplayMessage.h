void DisplayMessage(const char * szMessage);
