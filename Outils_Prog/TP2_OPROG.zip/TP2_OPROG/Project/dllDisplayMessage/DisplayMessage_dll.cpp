#include "DisplayMessage_dll.h"
#include <stdio.h>

void DisplayMessage(const char * szMessage){
    #ifdef _SYSTEM_LINUX
      printf ("%s \n", szMessage);
    #elif _SYSTEM_WINDOWS
      #include <windows.h>
      char buf[256];
      sprintf(buf,"%s\n",szMessage); 
      MessageBox(0, buf, "Widows Popup", 0);
    #endif

}











