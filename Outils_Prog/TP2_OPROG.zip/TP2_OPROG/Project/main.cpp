#include <iostream>
#include <stdio.h>
#include "libDisplayMessage/DisplayMessage.h"

using namespace std;

int main() 
{
    DisplayMessage("Hello World !");
    return 0;
}
