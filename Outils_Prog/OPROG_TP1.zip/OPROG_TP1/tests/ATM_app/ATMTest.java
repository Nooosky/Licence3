package ATM_app;


import org.junit.Before;
import org.junit.Test;

import static ATM_app.ATM.*;
import static java.lang.invoke.MethodHandles.catchException;
import static org.junit.Assert.*;

import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ATMTest {


    ATM atm = null;

    @Before
    public void setUp(){
        atm = new ATM();
    }


    @Test(expected = ATM.NullCardException.class)
    public void testInsertCard1() throws ATM.NullCardException {
        atm.insertCard(null);
    }

    @Test
    public void inputPin() {
        assertEquals(atm.inputPin(0), -1);
        assertNotEquals(atm.inputPin(0), -3);
        assertNotEquals(atm.inputPin(0), 0);
        assertNotEquals(atm.inputPin(0), -2);
    }

    @Test
    public void chooseAmount() {
        assertEquals(atm.chooseAmount(1000), -1);
        assertNotEquals(atm.chooseAmount(1000), -2);
        assertNotEquals(atm.chooseAmount(1000), 0);
        assertNotEquals(atm.chooseAmount(1000), -3);

    }

    @Test
    public void takeCard() {
        assertEquals(atm.takeCard(), null);
    }

    @Test
    public void takeBills() {
        assertEquals(atm.takeBills(), null);
    }

    @Test
    public void test_insertCard_with_blocked_card() throws ATM.NullCardException {
        Card mockedCard = Mockito.mock(Card.class);
        Mockito.when(mockedCard.isBlocked()).thenReturn(true);

        assertEquals(atm.insertCard(mockedCard), -2);
    }

    @Test
    public void test_inputPin_with_blocked_card() throws ATM.NullCardException{
        assertEquals(atm.inputPin(0000), -1);
    }

    @Test
    public void test_with_working_card() throws ATM.NullCardException {
        Card mockedCard = Mockito.mock(Card.class);
        Account mockedAccount = Mockito.mock(Account.class);
        Mockito.when(mockedCard.isBlocked()).thenReturn(false);
        Mockito.when(mockedCard.checkPin(0000)).thenReturn(true);
        Mockito.when(mockedCard.checkPin(1234)).thenReturn(false);
        Mockito.when(mockedAccount.canWithdraw(50)).thenReturn(true);
        Mockito.when(mockedAccount.canWithdraw(80)).thenReturn(false);
        Mockito.when(mockedCard.getAccount()).thenReturn(mockedAccount);


        assertEquals(atm.insertCard(mockedCard), 0);
        assertEquals(atm.inputPin(1234), -2);
        assertEquals(atm.inputPin(0000), 0);

        assertEquals(atm.chooseAmount(-1), -2);
        assertEquals(atm.chooseAmount(1000), -2);

        assertEquals(atm.chooseAmount(80), -3);
        assertEquals(atm.chooseAmount(50), 0);
    }





}