package l3info.oprog;

public class MyCard implements Card {

    Account account;
    int pin = -1;
    boolean canBePerso = true;

    public Account getAccount() {
        return account;
    }

    public boolean isBlocked() {
        return false;
    }

    public boolean checkPin(int p) {
        if (canBePerso || p != pin){
            return false;
        }
        return true;
    }

    public boolean setAccount(Account a){
        if (canBePerso && a != null){
            account = a;
            return true;
        }
        return false;
    }

    public boolean setPin(int p){
        if (canBePerso && p >= 0 && p <=9999){
            pin = p;
            return true;
        }
        return false;
    }

    public boolean endPersonalization(){
        if (canBePerso && pin != -1 && account != null){
            canBePerso = false;
            return true;
        }
        return false;
    }
}